import React from "react";
{/*function Car1({color}){
    return(
        <h2>My Car is {color}!</h2>
    );
}*/}
{/*function Car2(props){
    const {brand,model}=props;
    return(
        <h2>I love my {brand} {model} !</h2>
    );
}*/}
function Car3({color,model,...rest}){
    return(
        <h2>Car details {color} {model} {rest.brand}!</h2>
    );
}
export default Car3;
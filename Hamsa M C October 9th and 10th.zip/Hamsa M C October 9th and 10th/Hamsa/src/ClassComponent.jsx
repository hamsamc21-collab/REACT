import React from "react";
class Fruit extends React.Component{
    render(){
        return <h2>Fruit Component</h2>
}
}
export default Fruit;
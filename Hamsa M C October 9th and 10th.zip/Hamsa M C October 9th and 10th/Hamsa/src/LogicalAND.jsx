import React from "react";
function Car (props){
    return(
        <>
        {props.brand && <h1>My Car is a {props.brand}!</h1>}
       
        {/* it will execute only after execution of left side */}
        </>
    );
}
export default Car;
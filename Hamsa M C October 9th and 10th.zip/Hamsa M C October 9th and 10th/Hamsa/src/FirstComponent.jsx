import React from 'react'

function FirstComponent(){
    return (
        <div>
            <SecondComponent/>
            <h1>Component</h1>
            <h5>Hello from First Component</h5>
        </div>
    );
}

function SecondComponent(){
    return(
    <div>
        <h5>Hello from Second Component</h5>
    </div>
    );
}
export default FirstComponent;
import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import FirstComponent from './FirstComponent'
import Fruit from './ClassComponent'
import Argument from './Argument'
import Parent from './PropsChildren'
import ClassResult from './ConditionalRendering'
import Car from './LogicalAND'
import ClassResult1 from './TernaryOperator'
import Car3 from './Destructuring'
import Parent1 from './PropsDrilling'
function App() {
 const StudentName="Hamsa";

  return (
    <div>
    <FirstComponent/>
    <Fruit/>
    <Argument name="Hamsa"
    phno="8453259716"/>
   <Parent/>
   <ClassResult isresult={true}/>
    <Car brand="Ford"/>
    <ClassResult1 isresult={false}/>
    <Car3 brand="Ford" model="Musting" color="red" year={1969}/>
    <Parent1 StudentName={StudentName}/>
  </div>
   );
}

export default App;

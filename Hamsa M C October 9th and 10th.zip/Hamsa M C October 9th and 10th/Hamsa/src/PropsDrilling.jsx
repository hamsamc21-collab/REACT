import React from "react";

function Parent1({ StudentName }) {
  return (
    <div style={{ background: "#d4f1f4", margin: "10px", padding: "10px" }}>
      <h2>Parent Component</h2>
      <Child StudentName={StudentName} />
    </div>
  );
}

function Child({ StudentName }) {
  return (
    <div style={{ background: "#a4ebf3", margin: "10px", padding: "10px" }}>
      <h3>Child Component</h3>
      <GrandChild StudentName={StudentName} />
    </div>
  );
}

function GrandChild({ StudentName }) {
  return (
    <div style={{ background: "#75e6da", margin: "10px", padding: "10px" }}>
      <h4>GrandChild Component</h4>
      <GreatGrandChild StudentName={StudentName} />
    </div>
  );
}

function GreatGrandChild({ StudentName }) {
  return (
    <div style={{ background: "#189ab4", margin: "10px", padding: "10px" }}>
      <h5>GreatGrandChild Component</h5>
      <p>
        Hello <b>{StudentName}</b>, this value was passed from App Component
        through 3 other Components!
      </p>
    </div>
  );
}

export default Parent1;

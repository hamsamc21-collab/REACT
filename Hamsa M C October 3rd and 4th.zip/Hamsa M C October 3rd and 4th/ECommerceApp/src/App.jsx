import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import HelloWorld from './HelloWorld'
import './App.css'



function App() {
 return(
        <div>
            <h1>Hello world</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit perspiciatis adipisci magnam voluptatibus veniam tempore perferendis quis fuga ea ab cupiditate saepe cum consequuntur, sit quidem, voluptate consectetur distinctio. Voluptatem.</p>
            <HelloWorld/>
           
      
       </div>
    
  )
}
  

export default App


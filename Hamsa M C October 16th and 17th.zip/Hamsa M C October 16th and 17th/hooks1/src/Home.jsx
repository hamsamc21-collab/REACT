import React from 'react'
import { useNavigate } from 'react-router-dom';

function Home() {
    const navigate=useNavigate();
    function handleLogin(){
        console.log("Button is clicked");
        navigate('/contact');
    }
  return (
    <div>
         <button onClick={handleLogin}>Click</button>
    </div>
  )
}
export default Home;

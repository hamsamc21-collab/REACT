import React, { useState,useEffect } from 'react'

 function Count() {
    const [Count,setCount]=useState(0);

    useEffect(()=>{
        console.log("Count changed:",Count);
    },[Count]);
  return (
    <div>
        <h2>Count:{Count}</h2>
        <button onClick={()=>setCount(Count+1)}>Increase</button>

    </div>
  )
}
export default Count;

import React from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';

import UseEffect from './Useeffect';
import Timer from './Timer';
import Count from './Count';
import UsersList from './UsersList';
import { Greeting, Temperature } from './Greeting';
import External from './External';
import Button from './Button';
import ProductCard from './ProductCard';
import Index from './index';
import Home from './Home';
import About from './About';
import Contact from './Contact';

import { BrowserRouter, Routes, Route } from 'react-router-dom'; 

function App() {
  return (
    <div>
      {/*<UsersList />
      <Greeting />
      <Temperature value={35} />
      <External />
      <Button />
      <br />
      <ProductCard />*/}
      {/* <Timer /> */}
      {/* <UseEffect /> */}
      {/* <Count /> */}

      <h1>This is App File</h1>

      <BrowserRouter>
        <Routes>
          <Route path='/error' element={<h1>Page not found</h1>}></Route>
          <Route path="/" element={<Index />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

import React from 'react';

const style = {
  backgroundColor: "lightblue",
  padding: "10px",
  borderRadius: "5px",
};

//Static inline css
function Greeting() {
  return (
    <div>
      <h2 style={style}>Hello Inline CSS!</h2>
    </div>
  );
}

//Dynamic inline css
function Temperature({ value }) {
  const color = value > 30 ? "red" : "blue";
  return (
    <p style={{ color }}>
      The temperature is {value}°C
    </p>
  );
}

// Named exports
export { Greeting, Temperature };

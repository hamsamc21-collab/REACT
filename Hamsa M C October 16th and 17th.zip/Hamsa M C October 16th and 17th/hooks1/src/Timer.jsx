import React, { useState,useEffect } from 'react'
function Timer(){
    const[Seconds,setSeconds]=useState(0);
    useEffect(()=>{
        const timer=setInterval(()=>{
            setSeconds((s)=>s+1);
        },1000);

        //cleanup function
        return()=>{
            clearInterval(timer);
            console.log("Timer cleared!");
        };
        },[]); //run once
        return <h2>Time: {Seconds}s</h2>
}
export default Timer;
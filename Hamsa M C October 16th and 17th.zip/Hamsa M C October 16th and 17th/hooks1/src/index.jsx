import React from 'react'
import {BrowserRouter,Link} from 'react-router-dom'

 function Index() {
  return (
    <div><h1>This is Index Page</h1>
        <nav>
            <Link to='/Home'>Home Page</Link>
             <Link to='/About'>About Page</Link>
              <Link to='/Contact'>Contact Page</Link>
        </nav>
        <navLink to='/Home'>Home Page</navLink>
    </div>
  )
}
export default Index;
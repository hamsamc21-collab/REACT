import React from 'react'
import "./ExternalCss.css";

function External() {
  return (
    <div>
        <h1 className="title">React External CSS</h1>
    </div>
  )
}
export default External;

import React from 'react'
import styled from "styled-components";

const Card=styled.div`
background-color:violet;
border-color:balck;
border-radius:10px;
padding:20px;
text-align:center;
box-shadow:0 2px 5px rgba(0,6,0,0.1);
color:green;
`;

const Title=styled.h3`
color"#333;
`

function ProductCard() {
  return (
    <Card>
        <Title>Product Name</Title>
        <p>$50.99</p>

    </Card>
   
  );
} 
export default ProductCard;

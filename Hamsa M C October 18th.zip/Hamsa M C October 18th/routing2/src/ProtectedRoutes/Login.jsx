import React from 'react'

function Login() {
    const handleLogin=()=>{
        //save fake auth token in local storage
        localStorage.setItem("auth","true");
        window.location.href="/DashBoard";  //redirect to dashboard page
    };
  return (
    <div>
        <h2>This is a Login Page</h2>
        <button onClick={handleLogin}>Login</button>
    </div>
  )
}
export default Login;
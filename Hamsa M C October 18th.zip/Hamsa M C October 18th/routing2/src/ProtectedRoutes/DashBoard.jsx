import React from 'react'

export default function DashBoard() {
  return (
    <div>This is DashBoard</div>
  )
}

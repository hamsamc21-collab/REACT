import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ProtectedRoutes from './ProtectedRoutes/ProtectedRoutes.jsx'
import Login from './ProtectedRoutes/Login.jsx'
import Home from './ProtectedRoutes/Home.jsx'
import DashBoard from './ProtectedRoutes/DashBoard.jsx'
import {BrowserRouter,Routes,Route} from "react-router-dom"
import User from './DynamicRouting.jsx'

function App() {


  return (
    <div>
      <h1>Protected Routes Example</h1>
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/login" element={<Login/>}/>
      <Route path="/User/:id" element={<User/>}/>

      <Route path="/DashBoard" element={
        <ProtectedRoutes>
          <DashBoard/>
        </ProtectedRoutes>
      }/>
    </Routes>
    </BrowserRouter>
    </div>
  )
}

export default App;
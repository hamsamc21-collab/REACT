import React from 'react'

 function Personlinfo() {
  return (
    <div> This is Personlinfo Page</div>
  )
}
export default Personlinfo;

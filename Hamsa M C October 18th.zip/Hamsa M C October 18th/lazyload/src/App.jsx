import { useState, lazy,Suspense } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import Team from './Team.jsx'
import Personlinfo from './Personlinfo.jsx'

import {Route,Routes, BrowserRouter} from "react-router-dom"


const Home=lazy(()=>import("./Home"));
const About=lazy(()=>import("./About"));
const Contact=lazy(()=>import("./Contact"));

function App() {
   return (
    <Suspense fallback={<h3>Loading.....</h3>}>
      <BrowserRouter>
    <Routes>
    <Route path="/" element={<h1>This is Root Page</h1>}/>
    <Route path="/Home" element={<Home/>}/>
    <Route path="/About" element={<About/>}/>
    <Route path="/Contact" element={<Contact/>}/>
    <Route path="/Team" element={<Team/>}/>
    <Route path="/Personalinfo" element={<Personlinfo/>}/>


    </Routes>
    </BrowserRouter>
    </Suspense>

    
  )
}

export default App

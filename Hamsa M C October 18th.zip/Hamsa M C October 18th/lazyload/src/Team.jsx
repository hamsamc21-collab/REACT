import React from 'react'

 function Team() {
  return (
    <div> This is Team Page</div>
  )
}
export default Team;

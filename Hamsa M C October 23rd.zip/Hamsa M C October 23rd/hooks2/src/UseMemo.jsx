import React,{useMemo,useState} from 'react'
 function UseMemo() {
    const[count,setCount]=useState(0);
    const[text,setText]=useState("");

    function slowCalculation(num){
        console.log("Running slow calculation..");
        for(let i=0;i<100000000;i++){}
            return num*2;
        
    }
   
    //useMemo caches the result until count changes
    const result=useMemo(()=> slowCalculation(count),[count]);
     console.log( "Result of Count is :",result);

    return(
        <div>
            <h3>Slow result:{result} </h3>
            <button onClick={()=>setCount(count+1)}>Increment</button>
            <input value={text} onChange={(e)=>setText(e.target.value)}
            placeholder="Type here.."/>
        </div>
    );
}

export default UseMemo;

import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Component1 from './ContextAPI'
import UseRef from './UseRef'
import AccessDOMEle from './AccessDOMEle'
import TrackingState from './TrackingState'
import Counter from './UseReducer'
import UseMemo from './UseMemo'
import Parent from './useCallback'
import CounterApp from './CounterApp'
function App() {


  return (
    <>
   <Component1/>
   <UseRef/>
   <AccessDOMEle/><br></br>
   <hr></hr>
   <TrackingState/>
   <hr></hr>
   <Counter/>
   <hr></hr>
   <UseMemo/>
   <hr></hr>
   <Parent/>
   <hr></hr>
   <CounterApp/>
   </>
  )
}

export default App

import React,{useState,useCallback} from 'react'

 function Child({onClick}) {
    console.log("Child Component rerender");
    return <button onClick={onClick}>Click Me</button>
 
}
function Parent(){
    const[count,setCount]=useState(0);

    //useCallback keeps the same function unles dependencies change
    const handleClick=useCallback(()=>{
        console.log("Button Clicked");
    },[]);  //NO dependency -> Same function always

    return(
        <div>
            <h3>Count:{count}</h3>
            <button onClick={()=>setCount(count+1)}>Increment Count</button>
            <Child onClick={handleClick}/>
        </div>
    )
}
export default Parent;

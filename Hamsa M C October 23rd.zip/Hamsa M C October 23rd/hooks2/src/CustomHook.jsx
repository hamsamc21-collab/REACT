import {useState} from "react"


//Custom hook to manage counter logic
function useCounter(initialValue=0){
    const[count,setCount]=useState(initialValue);

    const increment=()=>setCount(count+1);
    const decrement=()=>setCount(count-1);
    const reset=()=>setCount(initialValue);

    //Return anything you wnat to share
   return {count,increment,decrement,reset};
   //console.log(count,increment,decrement,reset);

}
export default useCounter;
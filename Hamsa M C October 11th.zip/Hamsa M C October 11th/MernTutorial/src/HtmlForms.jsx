import React from 'react'

function HtmlForms() {
  return (
    <div>
        <form>
            <label for="email">Email:</label>
            <input type="email" id="user"></input><br></br>
            <label for="password">Password:</label>
            <input type="password" id="user"></input><br></br>
            <button>Submit</button>
        </form>
    </div>
  )
}

export default HtmlForms
import React, { useState } from 'react'

function SimpleValidation() {
    const [num,setNum]=useState("");
    const [error,setError]=useState("");

    const handleSubmit=(e)=>{
        e.preventDefault();
        if(num>10){
            setError("");
            alert(`Number is greater than 10:${num}`);
        }else{
            setError("");
            alert(`Number is less than 10:${num}`);
           
        }
    };

  return (
    <div>
    <form onSubmit={handleSubmit}>
        <input type="Num" value={num} onChange={(e)=>setNum(e.target.value)}/>
        <button type="Submit">Submit</button>
        {error && <p style={{color:"red"}}>{error}</p>}
    </form>
    </div>
  );
}
export default SimpleValidation;

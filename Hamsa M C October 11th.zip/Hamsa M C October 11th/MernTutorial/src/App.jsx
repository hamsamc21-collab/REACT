import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForms from './ControlledForms'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './SimpleValidation'

export default function App() {
  return (
    <div>
      <HtmlForms/>
      <ControlledForms/>
      <TwoWayBinding/>
      <SimpleValidation/>
    </div>
  )
}

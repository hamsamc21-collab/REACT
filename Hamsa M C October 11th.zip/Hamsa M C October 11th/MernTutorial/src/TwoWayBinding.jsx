import { useState} from "react";
function TwoWayBinding(){
    const[message,setmessage]=useState("Hello");
    return(
        <div>
            <input type="text" value={message} onChange={(e)=>setmessage(e.target.value)}/>
            <p>You typed: {message}</p>
        </div>
    )
}
export default TwoWayBinding;